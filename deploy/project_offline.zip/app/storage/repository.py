"""Repository：把筛选记录持久化到 SQLite（含去重与附件哈希去重）。"""
from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime
from typing import Optional

from ..models import EmailDocument, RuleResult, LLMResult, FinalScore, ScreeningRecord
from .database import Database

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class Repository:
    def __init__(self, db: Database):
        self.db = db

    # ---------- 去重 ----------
    @staticmethod
    def dedup_key(doc: EmailDocument) -> str:
        """subject+sender+date+body_hash 辅助去重键."""
        import hashlib
        raw = "|".join([doc.subject or "", doc.sender or "", doc.date or "", doc.body_hash or ""])
        return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()

    def is_duplicate(self, doc: EmailDocument) -> bool:
        return self.db.exists_email(doc.message_id or "", self.dedup_key(doc))

    def attachment_known(self, content_hash: str) -> bool:
        if not content_hash:
            return False
        row = self.db.query("SELECT 1 FROM attachments WHERE content_hash=? LIMIT 1", (content_hash,))
        return bool(row)

    # ---------- 写入 ----------
    def save_email(self, doc: EmailDocument) -> bool:
        """返回 False 表示重复已跳过."""
        dk = self.dedup_key(doc)
        if self.db.exists_email(doc.message_id or "", dk):
            return False
        self.db.execute(
            """INSERT OR REPLACE INTO emails
               (email_id, message_id, subject, sender, recipients, cc, date,
                body_text, body_hash, source_path, processed_at, dedup_key)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (doc.email_id, doc.message_id or "", doc.subject or "", doc.sender or "",
             json.dumps(doc.recipients, ensure_ascii=False),
             json.dumps(doc.cc, ensure_ascii=False), doc.date or "",
             doc.body_text or "", doc.body_hash or "", doc.source_path or "",
             _now(), dk))
        for att in doc.attachments:
            meta = getattr(att, "metadata", {}) or {}
            cached = meta.get("cached_path", "")
            if not cached:
                continue
            # 附件解析去重依赖 content_hash；如尚未解析则为空 -> 标记 file sha
            sha = att.sha256 or ""
            if not sha and cached:
                try:
                    sha = hashlib.sha256(open(cached, "rb").read()).hexdigest()
                except OSError:
                    sha = ""
            self.db.execute(
                """INSERT OR REPLACE INTO attachments
                   (email_id, filename, file_type, sha256, content_hash, text,
                    metadata, extraction_status, warnings)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (doc.email_id, att.filename or "", att.file_type or "", sha,
                 att.content_hash or "", att.text or "",
                 json.dumps(meta, ensure_ascii=False), att.extraction_status or "",
                 json.dumps(att.warnings, ensure_ascii=False)))
        return True

    def save_entities(self, email_id: str, entities: list):
        rows = []
        for e in entities:
            rows.append((email_id, e.get("type", ""), e.get("text", ""), int(e.get("count", 1))))
        if rows:
            self.db.executemany("INSERT INTO entities (email_id, entity_type, text, count) VALUES (?,?,?,?)", rows)

    def save_rule(self, email_id: str, rr: RuleResult):
        self.db.execute(
            "INSERT OR REPLACE INTO rule_matches (email_id, result_json, rule_score) VALUES (?,?,?)",
            (email_id, json.dumps(rr.to_dict(), ensure_ascii=False), float(rr.rule_score)))
        for p in rr.matched_patterns:
            self.db.execute(
                """INSERT OR REPLACE INTO pattern_matches
                   (email_id, pattern_id, category, name, pattern_score, matched_terms,
                    evidence_snippets, window)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (email_id, p.pattern_id, p.category, p.name, float(p.pattern_score),
                 json.dumps(p.matched_terms, ensure_ascii=False),
                 json.dumps(p.evidence_snippets, ensure_ascii=False), p.window))

    def save_llm(self, email_id: str, llm: LLMResult):
        self.db.execute(
            "INSERT OR REPLACE INTO llm_results (email_id, llm_json, llm_status, evidence_stage) VALUES (?,?,?,?)",
            (email_id, json.dumps(llm.to_dict(), ensure_ascii=False), llm.llm_status,
             llm.evidence_stage or ""))

    def save_score(self, email_id: str, fs: FinalScore):
        self.db.execute(
            """INSERT OR REPLACE INTO scores
               (email_id, final_score, priority, dimensions_json, stage_adjustment, negative_adjustment)
               VALUES (?,?,?,?,?,?)""",
            (email_id, float(fs.final_score), fs.priority,
             json.dumps(fs.dimension_scores, ensure_ascii=False),
             float(fs.stage_adjustment), float(fs.negative_adjustment)))

    def save_review_queue(self, rec: ScreeningRecord):
        if rec.score is None or rec.email is None:
            return
        if rec.score.priority in ("D",) and rec.score.final_score < 40:
            return  # D 不进入队列
        self.db.execute(
            """INSERT OR REPLACE INTO review_queue
               (email_id, priority, final_score, subject, sender, summary_zh, verification_targets, queued_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (rec.email_id, rec.score.priority, float(rec.score.final_score),
             rec.email.subject or "", rec.email.sender or "",
             rec.summary_zh or "", json.dumps(rec.verification_targets or [], ensure_ascii=False),
             _now()))

    def save_record(self, rec: ScreeningRecord, store_full: bool = True):
        """一次性保存全部（须先 save_email 判重后调用）。"""
        if rec.email is not None and store_full:
            self.save_email(rec.email)
        self.save_entities(rec.email_id, rec.rule.entities if rec.rule else [])
        if rec.rule is not None:
            self.save_rule(rec.email_id, rec.rule)
        if rec.llm is not None:
            self.save_llm(rec.email_id, rec.llm)
        if rec.score is not None:
            self.save_score(rec.email_id, rec.score)
            self.save_review_queue(rec)
