"""全局配置：路径、阈值、日志、DB、LLM（自 .env 读取）."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env", override=False)

CONFIG_DIR = ROOT / "config"
NEWS_SIGNAL_DIR = Path(os.getenv("NEWS_SIGNAL_DIR", CONFIG_DIR / "news_signal"))
DATA_DIR = ROOT / "data"
INBOX_DIR = DATA_DIR / "inbox"
PROCESSED_DIR = DATA_DIR / "processed"
REPORTS_DIR = DATA_DIR / "reports"
DB_PATH = Path(os.getenv("SCREENING_DB", DATA_DIR / "news_screening.db"))
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "app.log"
KNOWN_CASES_FILE = Path(os.getenv("KNOWN_CASES_FILE", DATA_DIR / "known_cases.jsonl"))
PERSON_ALIASES_FILE = CONFIG_DIR / "news_signal" / "person_aliases.yaml"

for _d in (DATA_DIR, INBOX_DIR, PROCESSED_DIR, REPORTS_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ---------- 运行开关 ----------
LLM_ENABLED = os.getenv("LLM_ENABLED", "1").strip().lower() not in ("0", "false", "no")
LLM_MODE = os.getenv("LLM_MODE", "template")          # api / template
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "60"))
LLM_TEMPLATE_DIR = Path(os.getenv("LLM_TEMPLATE_DIR", DATA_DIR / "llm_templates"))
LLM_TEMPLATE_FILE = LLM_TEMPLATE_DIR / "template_result.json"

OCR_ENABLED = os.getenv("OCR_ENABLED", "1").strip().lower() not in ("0", "false", "no")
TESSERACT_CMD = os.getenv("TESSERACT_CMD", "tesseract")

# ---------- 流水线阈值（可配置） ----------
LLM_TRIGGER_SCORE = float(os.getenv("LLM_TRIGGER_SCORE", "35"))
MIN_PRIORITY = os.getenv("MIN_PRIORITY", "D")        # 报告最低输出优先级

RULE_TRIGGER_EXTRA = bool(os.getenv("RULE_TRIGGER_EXTRA", "1").strip() not in ("0", "false", "no"))
# 低于阈值仍送 LLM 的条件：
#  E 类原始证据词 >= 1 且 (实体人名或目标角色词命中) 且 具体金额存在


def priority_min_value(p: str) -> float:
    return {"S": 90, "A": 75, "B": 60, "C": 40, "D": 0}.get(p.upper(), 0)
