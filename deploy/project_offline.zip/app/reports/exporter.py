"""报告导出：screening_results.jsonl + priority_queue.csv."""
from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import List

from ..models import ScreeningRecord

logger = logging.getLogger(__name__)

CSV_COLUMNS = [
    "priority", "final_score", "subject", "sender", "date", "target_persons",
    "categories", "matched_patterns", "one_sentence_summary",
    "reason_for_attention", "source_path",
]


def export_jsonl(records: List[ScreeningRecord], path: str | Path,
                 min_priority_value: float = 0.0) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    with open(path, "w", encoding="utf-8") as f:
        for rec in records:
            if rec.score is None or rec.score.final_score < min_priority_value:
                continue
            f.write(rec.to_jsonl_line() + "\n")
            written += 1
    logger.info("JSONL 导出 %d 条 -> %s", written, path)
    return written


def export_csv(records: List[ScreeningRecord], path: str | Path,
               min_priority_value: float = 0.0) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        w.writeheader()
        for rec in records:
            if rec.score is None or rec.email is None or rec.score.final_score < min_priority_value:
                continue
            llm = rec.llm
            row = {
                "priority": rec.score.priority,
                "final_score": rec.score.final_score,
                "subject": rec.email.subject or "",
                "sender": rec.email.sender or "",
                "date": rec.email.date or "",
                "target_persons": "、".join((llm.target_persons if llm else []) or rec.rule.target_persons_found or []),
                "categories": "、".join((llm.categories if llm else []) or rec.rule.matched_categories or []),
                "matched_patterns": "/".join(p.pattern_id for p in (rec.rule.matched_patterns if rec.rule else [])),
                "one_sentence_summary": (llm.one_sentence_summary if llm else "") or rec.summary_zh,
                "reason_for_attention": (llm.reason_for_attention if llm else "") or "",
                "source_path": rec.email.source_path or "",
            }
            w.writerow(row)
            written += 1
    logger.info("CSV 导出 %d 条 -> %s", written, path)
    return written
