# 台湾政治新闻爆料邮箱智能筛选引擎 V1

围绕「台湾政治负面新闻标识规则库 V1.0」（`config/news_signal/`）构建的**爆料邮箱新闻线索筛选引擎**：
从爆料邮箱材料（邮件正文 + 附件）中自动发现值得记者核查的高价值线索，输出 0-100 评分、
S/A/B/C/D 优先级队列、记者摘要与核查清单。

> 定位：发现「值得记者打开、核查、进一步调查」的新闻线索，**不是**认定犯罪；
> 未经核实的邮件内容一律以「邮件指称/爆料人称/尚待核实」表述，最终新闻判断由记者人工完成。

## 系统链路

```
邮件/附件(.eml+PDF/DOCX/XLSX/CSV/TXT/图片)
→ 文本解析(HTML转文本/附件文本层/OCR可选/表格保留行列)
→ 繁简归一 + 金额/账户/日期实体抽取
→ V1.0 新闻标识词典粗筛(H/M/C/E/S/X)
→ Pattern 新闻指纹匹配(P01-P20, 句/段/相邻3句四级窗口)
→ Negative Rules 反向判断(N01-N08 + X 词 + 上下文排除)
→ LLM 语义研判(OpenAI-compatible API 或离线模板后端)
→ 0-100 综合评分(scoring_rules 七维度 + 阶段/负向调整)
→ S/A/B/C/D 优先级队列
→ 记者摘要(80-180字) + 核查清单(verification_targets)
→ JSONL/CSV 报告 + SQLite 归档
```

## 安装与运行

```bash
pip install -r requirements.txt        # 见下方依赖清单
cp .env.example .env                    # 配置 LLM（不配则离线模板模式）
python tests/fixtures/generate_samples.py   # 生成 60 条测试样本(可选)

# 批量
python -m app.main --input data/inbox/
# 单文件
python -m app.main --file sample.eml
# 纯规则模式（不调用 LLM）
python -m app.main --file sample.eml --no-llm
# 只输出 B 及以上
python -m app.main --input data/inbox/ --min-priority B
# 规则包自检
python -m app.main --selfcheck
```

输出：`data/reports/screening_results.jsonl`、`data/reports/priority_queue.csv`；
日志：`logs/app.log`；SQLite：`data/news_screening.db`。

## 目录

```
app/
├── main.py            CLI 入口
├── config.py          配置(阈值/路径/.env)
├── models.py          EmailDocument/RuleResult/LLMResult/FinalScore…
├── parsers/           EML/PDF/DOCX/XLSX/CSV/TXT/图片 解析
├── preprocessing/     清洗/繁转简/金额账户日期抽取
├── rules/             词典/Pattern/Negative/RuleEngine(全部动态加载 YAML)
├── llm/               client/schemas(JSON校验+重试)/screener(规则包提示词)
├── scoring/           FinalScorer(七维度)/KnownNewsMatcher
├── storage/           SQLite Database/Repository(去重)
├── pipeline/          端到端编排
└── reports/           JSONL/CSV 导出
config/news_signal/    规则包(唯一知识底座，代码不硬编码关键词)
tests/                 38 项测试 + 60 条样本(fixtures)
data/                  inbox/processed/reports/news_screening.db
```

## 关键设计

- **规则包为纲**：taxonomy/keywords/pattern/negative/scoring 全部从 YAML 动态加载；
  词典含 H(高强度)/M(隐性)/C(场景)/E(原始证据)/S(程序)/X(反向) 六类，权重不等。
- **规则负责高召回，LLM 负责语义**：默认 `rule_score>=35`(可配)或命中高价值 Pattern /
  「E类证据+目标+金额」才调用 LLM；LLM 必须同时参考规则命中结果与原文。
- **Pattern 上下文窗口**：同一句 > 同段 > 相邻3句 > 全文，命中保留证据片段。
- **反向结果处理**：不起诉/无罪/查无不法 + 无新证据 → P20/EX 降权进入 C/D；
  旧案反向但提供新证据(如新银行流水) → 记录反向状态但**不**过滤，恢复调查价值。
- **繁简归一**：邮件文本繁转简后匹配，词典自动对齐；亲属称谓等少量口语变体有兜底。
- **LLM 输出校验**：JSON Schema 校验失败自动重试一次，二次失败 `llm_status=failed`
  单封跳过不中断整批。
- **容错**：损坏 PDF、OCR 失败、附件解析异常、单封乱码均记录后继续。
- **数据安全**：原始邮件只读不删不改不转发；日志掩码银行账号/身份证/手机号；
  API Key 仅环境变量；分析结果区分「爆料内容」与「已核实事实」。

## 依赖

python-dotenv、PyYAML、requests、pypdf、PyMuPDF、python-docx、openpyxl、Pillow、
opencc-python-reimplemented（繁转简）、pytest。
OCR 需另行安装 tesseract（可选，缺失时图片/扫描 PDF 标记 skipped 并记录 warning）。

## 测试

```bash
python -m pytest tests -q
```

38 项测试覆盖：规则包加载、词典/Pattern/Negative 引擎、解析器(EML/PDF/DOCX/XLSX/CSV)、
LLM JSON 校验、金额抽取、以及 60 条端到端样本的质量门槛
（高价值召回 ≥90%、E 类证据召回 ≥95%、隐性线索召回 ≥90%、困难负样本误报 ≤10%、
EX 旧闻不进 S、S/A/B 可解释性）。

## 已知新闻接口

`KnownNewsMatcher` 读 `data/known_cases.jsonl`（人物/公司/项目/结果/日期），
返回 `known/matched_events/possible_new_information`；V1 本地模拟，后续可接新闻库。

## 人物库扩展

`config/news_signal/person_aliases.yaml` 预留人物别名/现职/党籍/地区结构，V1 未强制建库。

## 限制（真实）

- LLM 默认离线模板后端为确定性兜底，语义判断能力有限；接真实 API 后质量会显著提升。
- OCR 依赖本机 tesseract，未安装环境图片类附件只标记 skipped。
- 人名识别为启发式(规则)，不支持大规模政要库；需靠 person_aliases.yaml 逐步扩充。
- 已知新闻匹配为本地 JSONL 模拟，未接实时新闻库。
- 评分校准基于 60 条样本集，实际分布可能偏移，需记者反馈迭代。
